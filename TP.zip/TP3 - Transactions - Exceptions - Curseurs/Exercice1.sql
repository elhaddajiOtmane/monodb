-- Exercice1: Soit le modèle relationnel suivant:
-- CLIENT (Codeclt, nom, prenom, tel)
-- PRODUIT (Codeprd, designation, prix, qte_dispo)
-- COMMANDE(numero, codeclt, datecmd)
-- DETAIL(numero, codeprd, qte_cmd)
-- 1) Créer la base de données et les tables 
-- en précisant les clés primaires et étrangères.
CREATE DATABASE S3EX1;
USE S3EX1;
CREATE TABLE CLIENT (Codeclt INT PRIMARY KEY,
nom VARCHAR(30), prenom VARCHAR(30),tel VARCHAR(10));
CREATE TABLE PRODUIT (Codeprd INT PRIMARY KEY,
 designation VARCHAR(30), prix FLOAT,qte_dispo INT);
CREATE TABLE COMMANDE(numero INT PRIMARY KEY,
codeclt INT,FOREIGN KEY(codeclt) REFERENCES CLIENT(codeclt),
datecmd DATE);
CREATE TABLE DETAIL(numero INT,FOREIGN KEY(numero) REFERENCES
COMMANDE(numero),codeprd INT,FOREIGN KEY(codeprd) REFERENCES
PRODUIT(codeprd),qte_cmd INT,PRIMARY KEY(numero,codeprd));
-- 2) Ecrire une procédure stockée qui permet d'ajouter 
-- un produit, si le produit existe déjà, on
-- modifiera la quantité en stock qui ne doit 
-- pas dépasser 100 sinon l'opération sera annulée.
-- (utiliser une transaction).
DELIMITER //
CREATE PROCEDURE ajouter_produit(codeprd1 INT,designation1 VARCHAR(30),
prix1 FLOAT,qte_dispo1 INT)
BEGIN
	SET AUTOCOMMIT=0;
	START TRANSACTION;
    IF(codeprd1 IN (SELECT codeprd FROM PRODUIT)) THEN
		UPDATE PRODUIT SET qte_dispo=qte_dispo+qte_dispo1
        WHERE codeprd=codeprd1;
	ELSE
		INSERT INTO PRODUIT VALUES(codeprd1,designation1,prix1,qte_dispo1);
    END IF;
    IF (SELECT qte_dispo FROM PRODUIT WHERE codeprd=codeprd1)>100 THEN
		ROLLBACK;        
	ELSE
		COMMIT;
	END IF;
END //
DELIMITER ;
CALL ajouter_produit(1,'PC',4500,1);
SELECT * FROM PRODUIT;
-- 3) Ecrire une procédure stockée permettant d'ajouter 
-- un client en gérant l’exception dans le cas
-- où le code client existe déjà. Afficher 
-- ‘Client ajouté avec succès’ si la procédure ajoute
-- correctement le client et ‘Ce code client est déjà 
-- utilisé’ dans le cas d’exception.
DELIMITER //
CREATE PROCEDURE ajouter_client(codeclt1 INT,nom1 VARCHAR(30),prenom1 VARCHAR(30),tel1 VARCHAR(10))
BEGIN
	DECLARE flag BOOLEAN DEFAULT 0;
    BEGIN
		DECLARE EXIT HANDLER FOR 1062 SET flag=-1;
        INSERT INTO CLIENT VALUES(codeclt1,nom1,prenom1,tel1);
        SELECT 'Client ajouté avec succès!' AS 'Succès';
    END;
    IF flag THEN
		SELECT 'Code client déjà utilisé!' AS 'Erreur';
	END IF;
END //
DELIMITER ;
CALL ajouter_client(1,'ALAMI','ALI','066777477');
-- 4) Créer une procédure stockée permettant d'ajouter une 
-- commande en gérant l'exception au
-- cas où le code client n'existe pas dans la table client. 
-- Afficher ‘Commande ajoutée avec
-- succès’ si la procédure arrive à ajouter la commande 
-- ou ‘Ce code client est inexistant’ dans le cas contraire.
DELIMITER //
CREATE PROCEDURE ajouter_commande(numero1 INT,codeclt1 INT,date1 DATE)
BEGIN
	DECLARE flag BOOLEAN DEFAULT 0;
    BEGIN
		DECLARE EXIT HANDLER FOR 1452 SET flag=-1;
        INSERT INTO COMMANDE VALUES(numero1,codeclt1,date1);
        SELECT 'Commande ajoutée avec succès!' AS 'Succès';
	END;
    IF flag THEN
		SELECT 'Code client n''existe pas dans la table CLIENT' AS 'Erreur';
    END IF;
END //
DELIMITER ;
CALL ajouter_commande(2,3,'2022/02/20');
-- 5) Créer une fonction permettant de retourner la quantité 
-- disponible d’un produit dont le code est passé en paramètre.
DELIMITER //
CREATE FUNCTION quantite_dispo(codeprd1 INT) RETURNS INT
READS SQL DATA
BEGIN
	DECLARE qte INT;
    SELECT qte_dispo INTO qte FROM PRODUIT WHERE codeprd=codeprd1;
    RETURN qte;
END //
DELIMITER ;
SELECT quantite_dispo(1);
-- 6) Créer une procédure qui permet d’ajouter une ligne dans 
-- la table détail, la procédure doit
-- gérer l’exception au cas où le code produit ou 
-- le numéro de commande n’existent pas dans
-- leurs tables d’origine. En plus si la quantité 
-- commandée et supérieure à la quantité
-- disponible en stock, la transaction sera annulée.
DELIMITER //
CREATE PROCEDURE ajouter_detail(numero1 INT,codeprd1 INT,qte_cmd1 INT)
BEGIN
	DECLARE flag BOOLEAN DEFAULT 0;
	SET AUTOCOMMIT=0;
    START TRANSACTION;
    BEGIN
		DECLARE EXIT HANDLER FOR 1452 SET flag=-1;
        INSERT INTO DETAIL VALUES(numero1,codeprd1,qte_cmd1);
        UPDATE PRODUIT SET qte_dispo=qte_dispo-qte_cmd1 WHERE codeprd=codeprd1;
        IF (SELECT qte_dispo FROM PRODUIT WHERE codeprd=codeprd1)<0 THEN
			SELECT 'Quantité insuffisante!' AS 'Erreur';
			ROLLBACK;
		ELSE
			SELECT 'Détail ajouté avec succès!' AS 'Succès';
			COMMIT;
		END IF;
    END;
    IF flag THEN
		SELECT 'numero de commande ou codeprd inéxistant!' AS 'ERREUR';
	END IF;
END//
DELIMITER ;
update produit set qte_dispo=50;
CALL ajouter_produit(2,'Souris',50,50);
CALL ajouter_detail(1,2,30);
-- 7) Créer une procédure stockée qui prend en paramètre le 
-- numéro de commande et un paramètre de sortie de type 
-- VARCHAR (30) dans lequel la procédure retournera la liste 
-- des désignations des produits concernés par cette commande 
-- (utiliser un curseur).
DELIMITER //
CREATE PROCEDURE liste_designation(numero1 INT,OUT liste VARCHAR(10000))
BEGIN
	DECLARE fin INT DEFAULT 0;
    DECLARE v_designation VARCHAR(30);
    DECLARE v_codeprd INT;
    DECLARE cur CURSOR FOR SELECT P.designation FROM PRODUIT P INNER JOIN
    DETAIL D ON P.Codeprd=D.codeprd WHERE D.numero=numero1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin=1;
		SET liste='';
        OPEN cur;
        parcours: LOOP
			FETCH cur INTO v_designation;
            IF fin=1 THEN
				LEAVE parcours;
			END IF;
            SET liste=CONCAT(liste,' ',v_designation);
        END LOOP parcours;
		CLOSE cur;
END//
DELIMITER ;
SET @liste='';
CALL liste_designation(1,@liste);
SELECT @liste;
2)
CREATE FUNCTION nb_clients_par_ville(varchar) RETURNS integer
    AS $$
    DECLARE
        nb_clients integer;
    BEGIN
        SELECT COUNT(*) INTO nb_clients
        FROM CLIENT
        WHERE ville = $1;
        RETURN nb_clients;
    END;
    $$
    LANGUAGE plpgsql;
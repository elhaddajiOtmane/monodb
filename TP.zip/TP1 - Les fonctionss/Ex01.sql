drop database ex01;
create database ex01;
use ex01;
-- 1) Create the tables of the relational model then fill these tables with a dataset.

create table client(
	codeclt int primary key,
    nomclt varchar(255),
    prenomclt varchar(255),
    adresse varchar(255),
    cp char(5),
    ville varchar(255)
);
create table produit (
	reference varchar(255) primary key,
    désignation varchar(255),
    prix real
);
create table technicien (
	codetec int primary key,
    nomtec varchar(255),
    prenomtec varchar(255) ,
    tauxhoraire real 
);
create table intervention (
	numero int primary key,
    date date,
    raison varchar(255),
    codeclt int,
    reference varchar(255),
    codetec int,
    foreign key (codeclt) references client(codeclt),
    foreign key (reference) references produit(reference),
    foreign key (codetec) references technicien(codete)
);

-- 2) Create a function that takes a city as a parameter and returns the number of customers who live in this city.
delimiter //
create function nbClt_ville(ville1 varchar(255))
returns int 
reads sql data
begin
declare nombre int;
set nombre = (select count(*) from client where ville=ville1);
return nombre;
end //
delimiter $$

-- 3) Create a function that returns the number of interventions performed by the technician whose name is passed as a parameter.
delimiter //
create function nbr_inter(nom varchar(255))
returns int
reads sql data
begin
declare nombre int;
set nombre = (select count(*) from intervention i inner join technicien t on i.codetec = t.codetec where t.nomtec = nom);
return nombre;
end //
delimiter $$

-- 4) Create a function that returns the sum of the prices of the products that have undergone
-- an intervention between two dates passed as a parameter and which are owned by the customer
-- to whom the name is passed as a parameter
delimiter //
create function func4(date1 date, date2 date, nom  varchar(255))
returns real
reads sql data
begin 
declare som real;
set som = (select sum(p.prix) from produit inner join intervention i on p.reference = i.reference 
inner join client c on i.codeclt=c.codeclt where (i.date between date1 and date2 and c.nomclt=nom));
return som;
end //
delimiter $$

-- 5) Create a function that returns the number of cities in which the technician 
-- whose name is passed as a parameter has worked.
delimiter //
create function func5(nom varchar(255))
returns int
reads sql data
begin
declare nombre int;
set nombre = (select count(distinct ville )  -- distinct : unique
from client c inner join 
intervention i on c.codeclt=i.codeclt inner join technicien t on i.codetec = t.codetec where t.nomtec = nom );
return nombre;
end //
delimiter $$

-- 6) Create a function that returns the number of customers who have not requested 
-- interventions between two dates passed as a parameter

delimiter //
create function func6(date1 date, date2 date)
returns int
reads sql data 
begin 
declare nombre int;
set nombre = (select count(*) from client where codeclt not in (select codeclt from intervention where date between date1 and date2 ));
return nombre;
end //
delimiter $$






